package ClasseLocal;

class Calculadora {
    public void executar() {
        class Operacao {
            public int somar(int a, int b) {
                return a + b;
            }
        }

        Operacao calc = new Operacao();
        int resultado = calc.somar(10, 15);
        System.out.println("Resultado da soma: " + resultado);
    }
}

public class CalculadoraDemo {
    public static void main(String[] args) {
        Calculadora servico = new Calculadora();
        servico.executar();
    }
}