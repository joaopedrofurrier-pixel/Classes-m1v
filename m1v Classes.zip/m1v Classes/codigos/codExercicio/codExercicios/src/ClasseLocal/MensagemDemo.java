package ClasseLocal;

class Mensagem {
    public void executar() {
        class Texto {
            public void exibir(String texto) {
                System.out.println(texto);
            }
        }

        Texto msg = new Texto();
        msg.exibir("Olá! Esta é uma classe local.");
    }
}

public class MensagemDemo {
    public static void main(String[] args) {
        Mensagem servico = new Mensagem();
        servico.executar();
    }
}