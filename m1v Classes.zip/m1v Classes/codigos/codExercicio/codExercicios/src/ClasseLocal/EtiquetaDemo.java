package ClasseLocal;

class Etiqueta {
    public void executar() {
        class Formato {
            public void exibirTitulo(String titulo) {
                System.out.println("=== " + titulo.toUpperCase() + " ===");
            }
        }

        Formato etiqueta = new Formato();
        etiqueta.exibirTitulo("Relatório Semanal");
    }
}

public class EtiquetaDemo {
    public static void main(String[] args) {
        Etiqueta servico = new Etiqueta();
        servico.executar();
    }
}