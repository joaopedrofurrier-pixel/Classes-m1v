package ClasseLocal;

class Validador {
    public void executar() {
        class Checagem {
            public boolean ehPositivo(int numero) {
                return numero > 0;
            }
        }

        Checagem validador = new Checagem();
        boolean resultado = validador.ehPositivo(5);
        System.out.println("O número é positivo? " + resultado);
    }
}

public class ValidadorDemo {
    public static void main(String[] args) {
        Validador servico = new Validador();
        servico.executar();
    }
}