package ClasseLocal;

class Saudacao {
    public void executar() {
        class Cumprimento {
            public void cumprimentar(String nome) {
                System.out.println("Seja bem-vindo, " + nome + "!");
            }
        }

        Cumprimento saudacao = new Cumprimento();
        saudacao.cumprimentar("Carlos");
    }
}

public class SaudacaoDemo {
    public static void main(String[] args) {
        Saudacao servico = new Saudacao();
        servico.executar();
    }
}