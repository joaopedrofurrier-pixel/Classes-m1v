package ClasseAbstrata;

abstract class Animal {
    public abstract void emitirSom();
}

class Cachorro extends Animal {

    @Override
    public void emitirSom() {
        System.out.println("Au Au");
    }
}

class Gato extends Animal {

    @Override
    public void emitirSom(){
        System.out.println("Miau Miau");
    }
}

public class AnimalDemo {
    public static void main(String[] args) {
        Cachorro c = new Cachorro();
        Gato g = new Gato();
        c.emitirSom();
        g.emitirSom();
    }
}
