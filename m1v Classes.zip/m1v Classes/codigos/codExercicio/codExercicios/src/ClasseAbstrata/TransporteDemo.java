package ClasseAbstrata;

abstract class Transporte {
    public abstract void mover();
}

class Carro extends Transporte {

    @Override
    public void mover(){
        System.out.println("O CARRO ESTA SE MOVENDO!");
    }
}

public class TransporteDemo {
    public static void main(String[] args) {
        Carro c = new Carro();
        c.mover();
    }
}
