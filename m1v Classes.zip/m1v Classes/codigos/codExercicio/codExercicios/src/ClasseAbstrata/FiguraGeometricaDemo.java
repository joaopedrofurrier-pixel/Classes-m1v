package ClasseAbstrata;

abstract class FiguraGeometrica {
    protected int base = 10;
    protected int altura = 10;

    public abstract void mostrarArea();
}

class Calculo extends FiguraGeometrica {

    @Override
    public void mostrarArea(){
        System.out.println("A sua area eh:  " + base * altura);
    }
}



public class FiguraGeometricaDemo {
    public static void main(String[] args) {
        Calculo c = new Calculo();
        c.mostrarArea();

    }
}
