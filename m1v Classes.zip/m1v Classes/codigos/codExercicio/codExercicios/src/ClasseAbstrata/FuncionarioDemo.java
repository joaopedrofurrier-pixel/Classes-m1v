package ClasseAbstrata;

abstract class Funcionario {
    protected String nomeFuncionario;
    protected double salarioBase = 4599.0;

    public Funcionario (String nomeFuncionario, double salarioBase){
        this.nomeFuncionario = nomeFuncionario;
        this.salarioBase = salarioBase;
    }

    public void mostrarFuncionario(){
        System.out.println("Com o bonus, o funcionario " + nomeFuncionario + " recebeu: ");
    }


    public abstract double CalcularBonus();
}

class BonusFuncionario extends Funcionario {
    private double bonus = 400;
    public BonusFuncionario(String nomeFuncionario, double salarioBase, double bonus) {
        super(nomeFuncionario, salarioBase);
        this.bonus = bonus;
    }

    @Override
    public double CalcularBonus(){
        double resultadoBonus = salarioBase + bonus;
        return resultadoBonus;
    }
}

public class FuncionarioDemo {
    public static void main(String[] args) {
        Funcionario f = new BonusFuncionario("Anderson", 4500.0, 400);
        f.mostrarFuncionario();
        System.out.println("RESULTADO DO BONUS!     " + f.CalcularBonus()+ " REAIS!!!");
    }
}
