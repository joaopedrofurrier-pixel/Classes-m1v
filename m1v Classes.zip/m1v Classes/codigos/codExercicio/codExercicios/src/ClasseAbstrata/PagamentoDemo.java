package ClasseAbstrata;

abstract class Pagamento {
    public abstract void mostrarProcessando();
}

class Processar extends Pagamento {

    @Override
    public void mostrarProcessando(){
        System.out.println("PROCESSANDO PAGAMENTO!");
    }
}

public class PagamentoDemo {
    public static void main(String[] args) {
        Processar p = new Processar();
        p.mostrarProcessando();
    }
}
