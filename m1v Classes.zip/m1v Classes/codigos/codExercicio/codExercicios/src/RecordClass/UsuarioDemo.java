package RecordClass;

record Usuario(String login, String email) {
    public Usuario {
        if (!email.contains("@")) {
            throw new IllegalArgumentException("E-mail inválido.");
        }
    }
}

public class UsuarioDemo {
    public static void main(String[] args) {
        Usuario usuario = new Usuario("anderson", "anderson@gmail.com");

        System.out.println("Login: " + usuario.login());
        System.out.println("Email: " + usuario.email());
        System.out.println(usuario);
    }
}