package RecordClass;

record Coordenada(int x, int y) {
    public Coordenada {
        if (x < 0 || y < 0) {
            throw new IllegalArgumentException("Coordenadas");
        }
    }
}

public class CoordenadaDemo {
    public static void main(String[] args) {
        Coordenada ponto = new Coordenada(10, 25);

        System.out.println("X: " + ponto.x());
        System.out.println("Y: " + ponto.y());
        System.out.println(ponto);
    }
}