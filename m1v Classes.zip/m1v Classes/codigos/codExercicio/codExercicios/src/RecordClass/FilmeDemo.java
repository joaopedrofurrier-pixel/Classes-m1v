package RecordClass;

record Filme(String titulo, int ano) {
    public Filme {
        if (ano < 1983) {
            throw new IllegalArgumentException("Ano inválido para a história do cinema.");
        }
    }
}

public class FilmeDemo {
    public static void main(String[] args) {
        Filme filme = new Filme("Scarface", 1983);

        System.out.println("Título: " + filme.titulo());
        System.out.println("Ano: " + filme.ano());
        System.out.println(filme);
    }
}