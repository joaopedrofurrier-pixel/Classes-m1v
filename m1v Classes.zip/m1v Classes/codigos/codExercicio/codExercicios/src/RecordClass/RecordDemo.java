package RecordClass;

record Produto(String nome, double preco) {}

public class RecordDemo {
    public static void main(String[] args) {
        Produto produto = new Produto("Notebook", 3500.00);
        System.out.println("Nome: " + produto.nome());
        System.out.println("Preço: " + produto.preco());
        System.out.println(produto);
    }
}