package RecordClass;

record Cidade(String nome, String estado) {
    public Cidade {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("Nome da cidade não pode ser vazio.");
        }
    }
}

public class CidadeDemo {
    public static void main(String[] args) {
        Cidade cidade = new Cidade("São Paulo", "SP");

        System.out.println("Nome: " + cidade.nome());
        System.out.println("Estado: " + cidade.estado());
        System.out.println(cidade);
    }
}