package ClasseConcreta;

class Livro {
    private String titulo;
    private String autor;

    public Livro(String titulo, String autor){
        this.titulo = titulo;
        this.autor = autor;
    }

    public void mostrarDados(){
        System.out.println("Titulo do livro: " + titulo);
    }
    public void mostrarDados2(){
        System.out.println("Autor do livro: " + autor);
    }
}


public class LivroDemo {
    public static void main(String[] args) {
        Livro book = new Livro("O Pequeno Príncipe", "Antoine de Saint-Exupéry");
        book.mostrarDados();
        System.out.println("======================================");
        book.mostrarDados2();
    }
}
