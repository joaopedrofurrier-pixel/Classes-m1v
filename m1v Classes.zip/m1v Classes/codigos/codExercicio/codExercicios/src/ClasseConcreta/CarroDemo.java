package ClasseConcreta;

class Carro {
    private String marca;
    private String modelo;

    public Carro(String marca, String modelo){
        this.marca = marca;
        this.modelo = modelo;
    }

    public void exibir(){
        System.out.println("Marca do carro: " + marca + " modelo do carro: " + modelo);
    }

}

public class CarroDemo {
    public static void main(String[] args) {
        Carro c = new Carro("BMW", "320i");
        c.exibir();
    }
}
