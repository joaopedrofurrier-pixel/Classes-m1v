package ClasseConcreta;

class Aluno {
    private String nomeAluno;
    private double nota;

    public Aluno(String nomeAluno, double nota){
        this.nomeAluno = nomeAluno;
        this.nota = nota;
    }

    public void exibir(){
        System.out.println("A nota do aluno: " + nomeAluno + " eh " + nota);
    }
}

public class AlunoDemo {
    public static void main(String[] args) {
        Aluno a = new Aluno("Anderson", 10);
        a.exibir();
    }
}
