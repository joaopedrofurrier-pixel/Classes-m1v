package ClasseConcreta;

class Conta {
    private double numero;
    private double saldo;

    public Conta(double numero, double saldo){
        this.numero = numero;
        this.saldo = saldo;
    }

    public void mostrarSaldo(){
        System.out.println("Saldo atual: " + saldo);
    }

}

class Deposito {
    private double valorDeposito;

    public Deposito(double valorDeposito){
        this.valorDeposito = valorDeposito;
    }


    public void depositar(){

        System.out.println("Informe o valor do deposito: " + valorDeposito);
    }
}

public class ContaDemo {
    public static void main(String[] args) {
        Conta c = new Conta(2837213, 6967.00);
        c.mostrarSaldo();

        Deposito dep = new Deposito(54);
        dep.depositar();


    }
}
