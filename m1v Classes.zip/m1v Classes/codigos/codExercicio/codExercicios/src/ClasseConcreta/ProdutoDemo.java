package ClasseConcreta;

class Produto {
    private String nomeProduto;
    private double preco;

    public Produto(String nomeProduto, double preco){
        this.nomeProduto = nomeProduto;
        this.preco = preco;
    }

    public void exibirPreco(){
        System.out.println("O preço do " + nomeProduto + " eh " + preco);
    }
}

public class ProdutoDemo {
    public static void main(String[] args) {
        Produto p = new Produto("Perfume", 849.99);
        p.exibirPreco();
    }
}
