package ClasseFinal;

final class ConstantesApp {
    public void mostrarNomeSistema(){
        System.out.println("O nome do sistema usado atualmente eh Windows 10!!");
    }
}

public class ConstantesAppDemo {
    public static void main(String[] args) {
        ConstantesApp c = new ConstantesApp();
        c.mostrarNomeSistema();
    }
}
