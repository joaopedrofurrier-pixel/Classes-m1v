package ClasseFinal;

final class ConversorTemp{
    public double paraFahrenheit(double c, double f){
        return c + f;
    }
}

public class ConversorDemo {
    public static void main(String[] args) {
        ConversorTemp c = new ConversorTemp();
        System.out.println("Temperatura em Fahrenheit: " + c.paraFahrenheit(45, 273));
    }
}
