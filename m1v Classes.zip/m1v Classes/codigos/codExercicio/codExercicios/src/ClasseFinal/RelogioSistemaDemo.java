package ClasseFinal;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;


final class RelogioSistema {
    public void mostrarHora(){
        LocalTime horaAtual = LocalTime.now();

        DateTimeFormatter formatador = DateTimeFormatter.ofPattern("HH:mm:ss");

        System.out.println("agora sao exatamente: " + horaAtual.format(formatador));
    }
}

public class RelogioSistemaDemo {
    public static void main(String[] args) {
        RelogioSistema r = new RelogioSistema();
        r.mostrarHora();
    }
}
