package ClasseFinal;

import java.util.Scanner;

final class ValidadorCpf {
    public boolean validar(String cpf){
        System.out.println("analisando formato do cpf: " + cpf);

        return cpf !=null;
    }
}

public class ValidadorCpfDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ValidadorCpf v = new ValidadorCpf();

        System.out.println("Coloque seu CPF para ser validado: ");
        String cpfDigitado = scanner.nextLine();

        boolean resultado = v.validar(cpfDigitado);
        System.out.println("RESULTADO " + resultado);
    }
}
