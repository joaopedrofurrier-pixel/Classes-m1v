package ClasseFinal;

final class ConfiguracaoSistema {
    public void mostrarVersao(){
        System.out.println("A versao mais recente do sistema eh a 16.4.2!");
    }
}

public class ConfiguracaoSistemaDemo {
    public static void main(String[] args) {
        ConfiguracaoSistema cs = new ConfiguracaoSistema();
        cs.mostrarVersao();
    }
}
