package ClasseAnonima;

interface Alarme {
    void disparar();
}

public class InterfaceAlarmeDemo {
    public static void main(String[] args) {
        Alarme meuAlarme = new Alarme() {
            @Override
            public void disparar() {
                System.out.println("Bora levantar magnata");
            }
        };

        meuAlarme.disparar();
    }
}