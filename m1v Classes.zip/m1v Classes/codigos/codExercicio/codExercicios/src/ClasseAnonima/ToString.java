package ClasseAnonima;

class Produto {
    public String obterNome() {
        return "Album da copa";
    }
}

public class ToString {
    public static void main(String[] args) {
        Produto produtoCustomizado = new Produto() {
            @Override
            public String toString() {
                return "Exibindo: " + obterNome() + " (Modificado via classe anônima)";
            }
        };

        System.out.println(produtoCustomizado.toString());
    }
}