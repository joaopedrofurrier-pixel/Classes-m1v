package ClasseAninhada;

class Sistema {
    public static String nomeSistema = "Windows";

    static class Log {
        public void emitirAviso() {
            System.out.println("[" + nomeSistema + "]: Um novo evento foi registrado no sistema.");
        }
    }
}

public class SistemaDemo {
    public static void main(String[] args) {
        Sistema.Log meuLog = new Sistema.Log();
        meuLog.emitirAviso();
    }
}