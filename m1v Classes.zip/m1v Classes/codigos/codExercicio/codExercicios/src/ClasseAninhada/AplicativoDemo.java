package ClasseAninhada;

class Aplicativo {
    public static String nomeApp = "WhatsApp";

    static class Versao {
        private String numeroVersao = "2.26.1";

        public void mostrarVersao() {
            System.out.println("O aplicativo " + nomeApp + " está rodando na versão " + numeroVersao + ".");
        }
    }
}

public class AplicativoDemo {
    public static void main(String[] args) {
        Aplicativo.Versao minhaVersao = new Aplicativo.Versao();
        minhaVersao.mostrarVersao();
    }
}