package ClasseAninhada;

class Biblioteca {
    public static String nomeBiblioteca = "Biblioteca Municipal";

    static class Categoria {
        private String genero = "Ficção Científica";

        public void exibirCategoria() {
            System.out.println("A categoria '" + genero + "' está disponível na " + nomeBiblioteca + ".");
        }
    }
}

public class BibliotecaDemo {
    public static void main(String[] args) {
        Biblioteca.Categoria minhaCategoria = new Biblioteca.Categoria();
        minhaCategoria.exibirCategoria();
    }
}