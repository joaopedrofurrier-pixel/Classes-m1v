package ClasseAninhada;

class EmpresaTI {
    public static String nomeEmpresa = "Tech Solutions";

    static class Setor {
        private String nomeSetor = "Desenvolvimento de Software";

        public void mostrarSetor() {
            System.out.println("O setor de " + nomeSetor + " pertence à empresa " + nomeEmpresa + ".");
        }
    }
}

public class EmpresaTiDemo {
    public static void main(String[] args) {
        EmpresaTI.Setor meuSetor = new EmpresaTI.Setor();
        meuSetor.mostrarSetor();
    }
}