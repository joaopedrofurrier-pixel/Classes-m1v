package ClasseAninhada;

class Universidade {
    public static String nomeUniversidade = "USP";

    static class Curso {
        private String nomeCurso = "Ciência da Computação";

        public void exibirDetalhes() {
            System.out.println("O curso de " + nomeCurso + " pertence à " + nomeUniversidade + ".");
        }
    }
}

public class UniversidadeDemo {
    public static void main(String[] args) {
        Universidade.Curso meuCurso = new Universidade.Curso();
        meuCurso.exibirDetalhes();
    }
}