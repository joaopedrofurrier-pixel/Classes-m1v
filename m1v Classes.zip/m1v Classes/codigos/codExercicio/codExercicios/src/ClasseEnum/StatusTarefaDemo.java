package ClasseEnum;

enum StatusTarefa {
    PENDENTE, EM_ANDAMENTO, CONCLUIDA
}

public class StatusTarefaDemo {
    public static void main(String[] args) {
        StatusTarefa status = StatusTarefa.PENDENTE;
        System.out.println("A tarefa está: " + status);
    }
}