package ClasseEnum;

enum CorSemaforo {
    VERMELHO, AMARELO, VERDE
}

public class CorSemafaroDemo {
    public static void main(String[] args) {
        CorSemaforo sinal = CorSemaforo.VERDE;
        System.out.println("O semáforo está: " + sinal);
    }
}