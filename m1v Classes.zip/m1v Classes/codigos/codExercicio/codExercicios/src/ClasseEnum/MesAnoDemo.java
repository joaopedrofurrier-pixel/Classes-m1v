package ClasseEnum;

enum MesAno {
    JANEIRO, FEVEREIRO, MARCO
}

public class MesAnoDemo {
    public static void main(String[] args) {
        MesAno mes = MesAno.JANEIRO;
        System.out.println("Mês atual: " + mes);
    }
}