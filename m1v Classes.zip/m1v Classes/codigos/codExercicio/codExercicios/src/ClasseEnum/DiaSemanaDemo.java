package ClasseEnum;

enum DiaSemana {
    SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO, DOMINGO
}

public class DiaSemanaDemo {
    public static void main(String[] args) {
        DiaSemana hoje = DiaSemana.SEXTA;
        System.out.println("O dia escolhido é: " + hoje);
    }
}