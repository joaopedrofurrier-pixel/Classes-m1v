package ClasseEnum;

enum NivelAcesso {
    ADMINISTRADOR, USUARIO, CONVIDADO
}

public class NivelAcessoDemo {
    public static void main(String[] args) {
        NivelAcesso permissao = NivelAcesso.ADMINISTRADOR;
        System.out.println("Nível de acesso definido: " + permissao);
    }
}