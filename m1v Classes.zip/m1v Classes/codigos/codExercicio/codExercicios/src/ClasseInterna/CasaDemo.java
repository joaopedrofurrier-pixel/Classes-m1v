package ClasseInterna;

class Casa {
    private String proprietario;

    public Casa(String proprietario) {
        this.proprietario = proprietario;
    }

    class Quarto {
        private String moveis;

        public Quarto (String moveis){
            this.moveis = moveis;
        }

        public void mostrarDados(){
            System.out.println("Proprietario da casa: " + proprietario);
            System.out.println("Movel do quarto: " + moveis);
        }
    }

}

public class CasaDemo {
    public static void main(String[] args) {
        Casa c = new Casa("Anderson");
        Casa.Quarto q = c.new Quarto("cama");
        q.mostrarDados();
    }
}
