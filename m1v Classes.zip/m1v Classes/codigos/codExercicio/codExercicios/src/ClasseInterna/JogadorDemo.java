package ClasseInterna;

class TimeFutebol {
    private String nomeTime = "Santos FC";

    class Jogador {
        private String nomeJogador = "Neymar Jr";
        private int numeroCamisa = 10;

        public void mostrar() {
            System.out.println("O jogador " + nomeJogador + " (Camisa " + numeroCamisa + ") joga no " + nomeTime + ".");
        }
    }
}

public class JogadorDemo {
    public static void main(String[] args) {
        TimeFutebol meuTime = new TimeFutebol();
        TimeFutebol.Jogador meuJogador = meuTime.new Jogador();
        meuJogador.mostrar();
    }
}