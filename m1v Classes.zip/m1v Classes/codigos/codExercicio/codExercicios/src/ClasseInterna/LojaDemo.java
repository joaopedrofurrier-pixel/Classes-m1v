package ClasseInterna;

class Loja {
    private String nomeLoja = "Supermercado Pague Menos";

    class Caixa {
        private int numeroCaixa = 5;

        public void abrirCaixa() {
            System.out.println("O Caixa número " + numeroCaixa + " da loja " + nomeLoja + " está aberto.");
        }
    }
}


public class LojaDemo {
    public static void main(String[] args) {
        Loja minhaLoja = new Loja();
        Loja.Caixa meuCaixa = minhaLoja.new Caixa();
        meuCaixa.abrirCaixa();
    }
}