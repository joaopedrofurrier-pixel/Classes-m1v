package ClasseInterna;

class Escola {
    private String nomeEscola;

    public Escola(String nomeEscola) {
        this.nomeEscola = nomeEscola;
    }

    class Turma {
        private String turmaEscolar;

        public Turma (String turmaEscolar){
            this.turmaEscolar = turmaEscolar;
        }

        public void mostrarDados(){
            System.out.println("Nome da melhor escola: " + nomeEscola);
            System.out.println("A melhor turma da escola: " + turmaEscolar);
        }
    }

}

public class EscolaDemo {
    public static void main(String[] args) {
        Escola e = new Escola("Etec Uirapuru");
        Escola.Turma t = e.new Turma("2 DS");
        t.mostrarDados();
    }
}