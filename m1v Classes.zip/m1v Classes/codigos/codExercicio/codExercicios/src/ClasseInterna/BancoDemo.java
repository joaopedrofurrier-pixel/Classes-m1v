package ClasseInterna;

class Banco {
    private String nomeBanco = "Banco Central Nacional";

    class Agencia {
        private String numeroAgencia = "0103-X";

        public void mostrarDados() {
            System.out.println("Agência Número: " + numeroAgencia + " | Pertencente ao: " + nomeBanco);
        }
    }
}


public class BancoDemo {
    public static void main(String[] args) {
        Banco meuBanco = new Banco();
        Banco.Agencia minhaAgencia = meuBanco.new Agencia();
        minhaAgencia.mostrarDados();
    }
}