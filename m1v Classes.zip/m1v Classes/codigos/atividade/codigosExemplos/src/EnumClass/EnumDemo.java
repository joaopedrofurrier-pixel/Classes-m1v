package EnumClass;

enum StatusPedido {
    PENDENTE,
    PROCESSANDO,
    ENVIANDO,
    ENTREGUE
}

public class EnumDemo {
    public static void main(String[] args) {
        StatusPedido status = StatusPedido.PROCESSANDO;

        System.out.println("Status atual: " + status);
    }
}
