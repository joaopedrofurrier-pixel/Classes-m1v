package ClasseInterna;

class Computador {
    private String marca;

    public Computador(String marca){
        this.marca = marca;
    }

    class Processador {
        private String modelo;

        public Processador(String modelo){
            this.modelo = modelo;
        }

        public void mostrarDados(){
            System.out.println("Marca do computador: " + marca);
            System.out.println("Modelo do processador: " + modelo);
        }
    }
}



public class InnerClassDemo {
    public static void main(String[] args) {
        Computador pc = new Computador("Dell");
        Computador.Processador proc = pc.new Processador("Ryzen 5600g");
        proc.mostrarDados();
    }
}
