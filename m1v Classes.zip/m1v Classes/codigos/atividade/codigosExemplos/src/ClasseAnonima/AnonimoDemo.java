package ClasseAnonima;

interface Saudacao {
    void mostrarMensagem();
}

public class AnonimoDemo {
    public static void main(String[] args) {
        Saudacao s = new Saudacao() {
            @Override
            public void mostrarMensagem() {
                System.out.println("Esta eh a msg da saudacao anonima!");
            }
        };
        s.mostrarMensagem();
    }
}
