package RecordClass;

record Aluno(String nome, int idade) {
    public Aluno {
        if (idade < 0){
            throw new IllegalArgumentException("Idade nao pode ser negativa!");
        }
    }
}

public class RecordDemo {
    public static void main(String[] args) {
        Aluno a = new Aluno("Anderson", 18);
        System.out.println("Nome: " + a.nome());
        System.out.println("Idade: " + a.idade());
        System.out.println(a);
    }
}
