package ClasseAbstrata;

abstract class Funcionario {
    protected String nome;

    public Funcionario (String nome){
        this.nome = nome;
    }

    public void mostrarNome(){
        System.out.println("Nome: " + nome);
    }

    public abstract double calcularSalario();

}

class FuncionarioCLT extends Funcionario {
    private double salarioBase;

    public FuncionarioCLT(String nome, double salarioBase) {
        super(nome);
        this.salarioBase = salarioBase;
    }

    @Override
    public double calcularSalario() {
        return salarioBase;
    }
}


public class FuncionarioDemo {
    public static void main(String[] args) {
        Funcionario f = new FuncionarioCLT("Anderson", 4000.0);
        f.mostrarNome();
        System.out.println("Salario R$ " + f.calcularSalario());
    }
}
