package ClassSealed;

sealed class Veiculo permits Carro, Moto {
    public void mover() {
        System.out.println("O veículo está em movimento.");
    }
}

final class Carro extends Veiculo {
    public void abrirPortaMalas(){
        System.out.println("Porta malas aberto!");
    }
}

final class Moto extends Veiculo {
    public void empinar(){
        System.out.println("A moto foi empinada com sucesso!");
    }
}

public class SealedDemo {
    public static void main(String[] args) {
        Carro c = new Carro();
        c.mover();
        c.abrirPortaMalas();

        System.out.println("=========================");

        Moto m = new Moto();
        m.mover();
        m.empinar();
    }
}
