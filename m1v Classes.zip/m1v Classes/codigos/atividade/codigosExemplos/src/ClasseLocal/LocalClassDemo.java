package ClasseLocal;

class Relatorio {
    public void gerar(){
        class Cabecalho {
            private String titulo;

            public Cabecalho(String titulo){
                this.titulo = titulo;
            }

            public void mostrar(){
                System.out.println("====" + titulo + "====");
            }
        }

        Cabecalho cab = new Cabecalho("Relatorio de vendas");
        cab.mostrar();
        System.out.println("Conteudo do relatorio...");
    }
}

public class LocalClassDemo {
    public static void main(String[] args) {
        Relatorio r = new Relatorio();
        r.gerar();
    }
}
