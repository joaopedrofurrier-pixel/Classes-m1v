package ClasseFinal;


final class UtilitarioMatematica {
    public int somar(int a, int b){
        return a + b;
    }
}

public class FinalDemo {
    public static void main(String[] args) {
        UtilitarioMatematica u = new UtilitarioMatematica();
        System.out.println("Soma: " + u.somar(20,20));
    }
}
